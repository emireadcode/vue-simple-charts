import type { SankeyDataType, SankeyTreeType } from "./type/";
import { from, filter, max } from 'rxjs';

  /*[
    {
        name: 'g',
        parentanditsweightinparent: [
            {
                name: 'f',
                weight: 0.78
            }
        ]
    },
    {
        name: 'd',
        parentanditsweightinparent: [
            {
                name: 'b',
                weight: 0.97
            }
        ]
    },
    {
        name: 'e',
        parentanditsweightinparent: [
            {
                name: 'd',
                weight: 0.87
            }
        ]
    },
    {
        name: 'a',
        parentanditsweightinparent: [
            {
                name: 'f',
                weight: 0.78
            },
            {
                name: 'g',
                weight: 0.32
            }
        ]
    },
    {
        name: 'c',
        parentanditsweightinparent: [
            {
                name: 'a',
                weight: 0.87
            },
            {
                name: 'c',
                weight: 0.87
            }
        ]
    },
    {
        name: 'f',
        parentanditsweightinparent: [
            {
                name: 'g',
                weight: 0.56
            }
        ]
    },
    {
        name: 'm',
        parentanditsweightinparent: [
            {
                name: 'f',
                weight: 0.45
            }
        ]
    },
    {
        name: 'b',
        parentanditsweightinparent: [
            {
                name: 'a',
                weight: 0.63
            },
            {
                name: 'f',
                weight: 0.27
            }
        ]
    }
  ]*/

function calculateValuePercentageInNode(link: SankeyDataType[number], datatable: SankeyDataType) {
  return 0;
}

function hasNoParents(item: SankeyTreeType[string]["parentanditsweightinparent"]) {
  if (item == null) {
    return false;
  }

  if (typeof item !== 'object') {
    return false;
  }

  const proto = Object.getPrototypeOf(item);
  if (proto !== null && proto !== Object.prototype) {
    return false;
  }

  for (var prop in item) {
    if (Object.prototype.hasOwnProperty.call(item, prop)) {
      return false;
    }
  }

  return true;
}

function aggregateAllRootNodesIntoLevelZero(sankeytree: SankeyTreeType) {
  let node: { [key: number]: string[]; } = {};
  node = {
    0: []
  };
  from(Object.values(sankeytree))
    .pipe(
      filter((item, i) => hasNoParents(item.parentanditsweightinparent))
    )
    .subscribe(
      root => node[0].push(root.name)
    )
  ;
  return node;
}

function isParentFoundInNodeAndWhere(node: { [key: number]: string[]; }, parentname: string) {
  let found = false, pos = -1;
  Object.values(node).forEach((item, i) => {
    if(item.includes(parentname)) {
      found = true;
      pos = i;
      return;
    }
  });
  return {found, pos};
}

function getAllParentsFoundStatusAndPos(node: { [key: number]: string[]; }, parentnodes: {[key: string]: {name: string; weight: number;};}) {
  let foundandpos: {found: boolean; pos: number;}[] = [];
  Object.values(parentnodes).forEach((parent, j) => {
    foundandpos.push(isParentFoundInNodeAndWhere(node, parent.name));
  });
  return foundandpos;
}

function areAllParentsFound(foundandpos: {found: boolean; pos: number;}[]) {
  let found = true;
  foundandpos.forEach(item => {
    if(!item.found) {
      found = false;
      return;
    }
  })
  return found;
}

function atleastOneParentFound(foundandpos: {found: boolean; pos: number;}[]) {
  let found = false;
  foundandpos.forEach(item => {
    if(item.found) {
      found = true;
      return;
    }
  })
  return found;
}

function getHighestIndexOfTruthfulFounds(foundandpos: {found: boolean; pos: number;}[]) {
  let maxindex = 0;
  from(foundandpos)
    .pipe(
      filter(item => item.found === true),
      max((a, b) => a.pos - b.pos)
    )
    .subscribe(
      max => maxindex = max.pos
    )
  ;
  return maxindex;
}

function findItemInNodeAndDeleteIfFoundNotAlone(node: { [key: number]: string[]; }, parentname: string) {
  let newnode = node, foundanddeleted = false, delpos = -1;
  Object.values(newnode).forEach((item, i) => {
    if(item.includes(parentname) && item.length > 1) {
      item.splice(item.findIndex(value => value === parentname), 1);
      foundanddeleted = true;
      delpos = i;
      return;
    }
  });
  return {newnode, foundanddeleted, delpos};
}

function shouldSkipOrNotAndReturnNode(item: {name: string; weight: number; parentanditsweightinparent: {[key: string]: {name: string; weight: number;};};}, newskipped: boolean[], foundanddeleted: boolean, delpos: number, newnode: { [key: number]: string[]; }) {
  let
    node = newnode, 
    skipped = newskipped,
    foundandpos = getAllParentsFoundStatusAndPos(
      node, 
      item.parentanditsweightinparent
    )
  ;

  if(atleastOneParentFound(foundandpos)) {
    let pos = getHighestIndexOfTruthfulFounds(foundandpos);
    if(!((pos+1) in node)) {
      node = {
        ...node,
        [pos+1]: []
      };
    }
    if(!(node[pos+1].includes(item.name))) {
      node[pos+1].push(item.name);
    }
    if(areAllParentsFound(foundandpos)) {
      if(foundanddeleted && delpos !== (pos+1) && delpos !== -1) {
        skipped.push(true);
      }
      else {
        skipped.push(false);
      }
    }
    else {
      skipped.push(true);
    }
  }
  else {
    skipped.push(true);
  }

  return {anothernewnode: node, newskipped: skipped};
}

function aggregateNodesIntoRespectiveLevels(sankeytree: SankeyTreeType) {
  let node: { [key: number]: string[]; } = aggregateAllRootNodesIntoLevelZero(sankeytree), counter = 0, done = false;
  do {
    let skipped: boolean[] = [];
    Object.values(sankeytree).forEach(item => {
      if(!hasNoParents(item.parentanditsweightinparent)) {
        let 
          {newnode, foundanddeleted, delpos} = findItemInNodeAndDeleteIfFoundNotAlone(node, item.name),
          {anothernewnode, newskipped} = shouldSkipOrNotAndReturnNode(item, skipped, foundanddeleted, delpos, newnode)
        ;
        node = anothernewnode;
        skipped = newskipped;
      }
    });
    if(!(skipped.includes(true))) {
      done = true;
    }
  }
  while(done === false);
  
  return node;
}

function addFromsWithoutParents(datatable: SankeyDataType, existinglink: SankeyTreeType) {
  let sankey = existinglink;
  datatable.forEach((link, i) => {
    let fromKey = link.from.toLowerCase().replace(/\s*/g, "");
    if(!(fromKey in sankey)) {
      sankey = {
        ...sankey,
        [fromKey]: {
          name: link.from,
          weight: link.value,
          parentanditsweightinparent: {}
        }
      };
    }
  });
  return sankey;
}

export function createSankeyLinks(datatable: SankeyDataType) {
  let sankey: SankeyTreeType = {};
  datatable.forEach((link, i) => {
    let 
      toKey = link.to.toLowerCase().replace(/\s*/g, ""),
      fromKey = link.from.toLowerCase().replace(/\s*/g, "")
    ;
    if(toKey in sankey) {
      sankey[toKey].parentanditsweightinparent = {
        ...sankey[toKey].parentanditsweightinparent,
        [fromKey]: {
          name: link.from,
          weight: link.value
        }
      };
      sankey[toKey].weight+=link.value;
    }
    else {
      sankey = {
        ...sankey,
        [toKey]: {
          name: link.to,
          weight: link.value,
          parentanditsweightinparent: {
            [fromKey]: {
              name: link.from,
              weight: link.value
            }
          }
        }
      };
    }
  });
  sankey = addFromsWithoutParents(datatable, sankey);
  let node = aggregateNodesIntoRespectiveLevels(sankey);
  console.log(node);
  console.log(sankey);
  return sankey;
}